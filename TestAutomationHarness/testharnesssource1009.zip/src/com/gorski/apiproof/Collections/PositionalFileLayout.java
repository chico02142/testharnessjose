package com.gorski.apiproof.Collections;

import java.util.ArrayList;
import java.util.HashMap;
import org.apache.poi.ss.usermodel.Cell;

public class PositionalFileLayout {
	private String fileName;
//	private String layoutFileType;
	private String layoutFile;
	private ArrayList<PositionalCell> posCells = new ArrayList<PositionalCell>();
	private ArrayList<HashMap<String, String>> resultMaps = new ArrayList<HashMap<String, String>>();
	private boolean hasHeader = true;
	private Character delim = '!';
	private String[] detail_cols = { "FILE_NAME", "BUSINESS_DOMAIN", "SOURCE_SYSTEM_CODE", "METADATA_VERSION",
			"DESCRIPTION", "FILE_FORMAT", "DELIMITER", "ENCODING", "FILE_NAMING_FORMAT", "HEADER_INFO",
			"HEADER_LINE_COUNT", "FOOTER", "FOOTER_LINE_COUNT", "FOOTER_FORMAT", "SCHEDULE_INTERVAL", "SCHEDULE_UNITS",
			"START_TIME", "SOURCE_DATASETS", "PREPARER_NAME", "PREPARER_EMAIL", "CONTACT_NAME", "CONTACT_EMAIL", "TAGS",
			"ROLES", "PARTITIONING_KEY", "OWNING_DEPT", "SENSITIVE_DATA_IN_SOURCE_FILE", "INGEST_TYPE",
			"MULTI_RECORD_TYPE_INDICATOR", "MULTI_RECORD_TYPE_INDICTR_POS", "FILE_STAGING_DIRECTORY", "CONNECTION_NAME",
			"TABLE_NAME", "HEADER_FORMAT", "PRIMARY_KEY", "DATABASE_NAME", "COPYBOOK_NAME" };
	private String[] layout_cols = { "FILE_NAME", "SCOLUMN_NAME", "SCOLUMN_DESCRIPTION", "SCOLUMN_TYPE", "SPOSITION",
			"SSIZE", "SREQUIRED", "SENCRYPTED", "SMASKED", "SCLASSIFICATION", "SAV_LIST", "SAV_RANGE", "SAV_RULE",
			"SFORMAT", "RCOLUMN_NAME", "RCOLUMN_TYPE", "RSIZE", "RENCRYPTED", "RMASKED", "REXPRESSION", "RFORMAT" };
	private String[] medeColumns = { "#", "BCBSMA - DWH Source Table ", "BCBSMA - DWH Source Field",
			"Field Logic (if Applicable)", "Field Alias", "Mede Field Name", "BCBSMA Description", "Data Type",
			"Character Length", "Valid Field  Values/Format", "Related Reports", "Comments related to each column",
			"Overall Logic / Conditions for the Exract" };

//	public PositionalFileLayout(String layoutFileType, String fileInput, String operation) {
	public PositionalFileLayout(String fileInput, String operation) {
		super();
		this.fileName = fileInput;
		//this.layoutFileType = layoutFileType;
		this.layoutFile = fileInput;
	}

	public static void main(String args[]) {
		String extractDir = "//BOS0105FAP03/Public/DWUSERS/DLAP_Analyst/Ingested Files/Be2ME/"
				+ "FINANCE/BROKER PAYMENT OR FINANCE ALL EXTRACT/";

		// + "RME/Modified RME Files/Re-Ingest/";

		String[] fileToRead = { "CD_DMN-IngestWB.xlsx", "CMN_CD-IngestWB.xlsx", "EXTRACT_CNTL-IngestWB.xlsx",
				"HLT_PLN_GRP-IngestWB.xlsx", "HLT_PLN_INSR_PLY-IngestWB.xlsx", "HLT_PLN_INSR_PLY_AGRM-IngestWB.xlsx",
				"HLT_PLN_INSR_PLY_BILL-IngestWB.xlsx", "HLT_PLN_INSR_PLY_STS-IngestWB.xlsx",
				"HLT_PLN_INSR_PLY_XREF-IngestWB.xlsx", "HLT_PLN_MBR-IngestWB.xlsx", "HLT_PLN_MBR_2_PRACT-IngestWB.xlsx",
				"HLT_PLN_MBR_ELIG-IngestWB.xlsx", "HLT_PLN_MBR_HLT_STS-IngestWB.xlsx",
				"HLT_PLN_MBR_ID_CARD_RQS-IngestWB.xlsx", "HLT_PLN_MBR_LIFE_VOL-IngestWB.xlsx",
				"HLT_PLN_MBR_MCAID-IngestWB.xlsx", "HLT_PLN_MBR_MCARE-IngestWB.xlsx",
				"HLT_PLN_MBR_MDCL_CDTN-IngestWB.xlsx", "HLT_PLN_MBR_MDCL_RCRD-IngestWB.xlsx",
				"HLT_PLN_MBR_PRIVACY_INFO-IngestWB.xlsx", "HLT_PLN_MBR_REINS-IngestWB.xlsx",
				"HLT_PLN_MBR_STS-IngestWB.xlsx", "HLT_PLN_MBR_SUBSIDY-IngestWB.xlsx", "HTL_PLN_MBR_RMK-IngestWB.xlsx",
				"PLN_MBR_ADR-IngestWB.xlsx", "PLN_MBR_ALT_ID-IngestWB.xlsx", "PLN_MBR_CTC-IngestWB.xlsx",
				"PLN_MBR_CTC_ADR-IngestWB.xlsx", "PLN_MBR_CTC_EMAIL-IngestWB.xlsx", "PLN_MBR_CTC_PH-IngestWB.xlsx",
				"PLN_MBR_EMAIL-IngestWB.xlsx", "PLN_MBR_NM-IngestWB.xlsx", "PLN_MBR_PH-IngestWB.xlsx",
				"SRC-IngestWB.xlsx", "SUBSCR_INV-IngestWB.xlsx", "SUBSCR_INV_DLNQNCY-IngestWB.xlsx",
				"SUBSCR_INV_RCPNT-IngestWB.xlsx", "TENANT-IngestWB.xlsx", "TEST_CMN_CD-IngestWB.xlsx",
				"TEST_HLT_PLN_INSR_PLY_AGRM-IngestWB.xlsx", "TEST_SRC-IngestWB.xlsx",
				"test_SUBSCR_INV_RCPNT-IngestWB.xlsx", "TSL_SRC_CD-IngestWB.xlsx", "TSL_SRC_DMN-IngestWB.xlsx" };
		// for(int i=20;i<fileToRead.length;i++) {
		// 	PositionalFileLayout layout = new PositionalFileLayout(extractDir+fileToRead[i]+"@Metadata","layout");
		// 	layout.setLayout();
		// }
//		PositionalFileLayout layout = new PositionalFileLayout(
//				extractDir + "ME_FIN_Cash_Detail.xlsx@Metadata", "layout");
//		layout.setLayout("MetaData");
		// new
		if(args.length<1) {
		extractDir = "//BOS0105FAP02/Public/cis/Test Support Group/101 Market Reporting/"
				+ "Extract Queries - Automation/";
		String sheetTab="Account Structure";
		sheetTab="Pharmacy Extract";
		sheetTab="Eligibility Extract";
		sheetTab="Medical Claim Extract";
		sheetTab="Medical Unique Id Extract";
		sheetTab="Pharmacy Unique ID Extract";
		sheetTab="DXCG Extract";
		sheetTab="HRMP Summary Extract";
		sheetTab="Lasered Members Extract";
		sheetTab="ESL Policies Extract";
		sheetTab="ESL Policy-Grp Extract";
		sheetTab="Sensitive Codes Extract";
		sheetTab="Inbound ASC Billing Extract";
		sheetTab="Inbound 50-100% Extract";
		sheetTab="Inbound 100% Claim Extract";
		sheetTab="Premium Extract";
		PositionalFileLayout layout = new PositionalFileLayout(
				extractDir + "MR_Mede_DataDictionary_Review_V4.0.xlsx@"+sheetTab, "layout");
		layout.setLayout(sheetTab);
		} else {
			/*
			 * use args if available
			 */
			if(args.length<2) {
				System.out.println("\n\n PositionalFileLayout inserts spreadsheet data into database.  ");
				System.out.println(" DTDMTX.Positional_File_Details and DTDMTX.Positional_File_Layout  ");
				System.out.println("\n\n Usage:  2 string values needed ");
				System.out.println(
					" Usage:  workbook_filename_with_directory, worksheet_name ");
			} else {
				PositionalFileLayout layout = new PositionalFileLayout(args[0]+"@"+args[1],"layout");
				layout.setLayout(args[1]);
			}
		}

	}

	public void readLayoutFile() {
		this.setLayout("MetaData");
	}

	public void readLayoutFile(String sheetname) {
		this.setLayout(sheetname);
	}
	
	public ArrayList<HashMap<String, String>> getResultMaps() {
		return resultMaps;
	}

	private void setLayout(String sheetName) {
		/*
		 * use XLS collector to read spreadsheet
		 */
		XLSobject layoutXLS = new XLSobject(layoutFile);
		HashMap<Integer, String> layoutMap = layoutXLS.getData(sheetName, delim);
		String layoutName = "";
		/*
		 * detail insert
		 */
		Integer layoutRowStart = 0;
		boolean keepdetails = false;
		String sqldetail = "INSERT INTO FILE_POSITIONAL_DETAILS (";
		String sqldetailvalues = "";
		/*
		 * read either metadata type or mede type
		 */
		if (sheetName.equalsIgnoreCase("MetaData")) {

			String detail_col_string = "";
			for (String detail_col : detail_cols) {
				detail_col_string = detail_col_string + detail_col + ",";
			}
			sqldetail = sqldetail + detail_col_string.substring(0, detail_col_string.length() - 1) 
			+ ") VALUES (";

			/*
			 * loop over spread sheet data for spec xls
			 */
			for (Integer row : layoutMap.keySet()) {
				String[] layoutStrings = layoutMap.get(row).split(delim.toString());
				if (layoutStrings[0].equalsIgnoreCase("Column Name"))
					layoutRowStart = row;
				System.out.println(layoutStrings[0] + " keepdetails " + keepdetails);
				if (layoutStrings[0].equalsIgnoreCase("Name"))
					layoutName = layoutStrings[1];
				/*
				 * get overall file details
				 */
				if (layoutStrings[0].equalsIgnoreCase("Name"))
					keepdetails = true;
				if (layoutStrings[0].equalsIgnoreCase("Column Level Metadata"))
					keepdetails = false;
				if (keepdetails) {
					if (layoutStrings.length > 1) {
						if (layoutStrings[1].length() > 50) {
							sqldetailvalues = sqldetailvalues + "'" + layoutStrings[1].substring(0, 50) + "',";
						} else {
							sqldetailvalues = sqldetailvalues + "'" + layoutStrings[1] + "',";
						}
					} else {
						sqldetailvalues = sqldetailvalues + "' ',";
					}
				}
			}
			sqldetail = sqldetail + sqldetailvalues.substring(0, sqldetailvalues.length() - 1) + ")";
			System.out.println("\n" + sqldetail);
			
			SQLDataObject sqldatadetail = new SQLDataObject("oracle", "DTDMTX", sqldetail);

			/*
			 * layout insert
			 */
			String sqllayout = "INSERT ALL ";
			String layout_col_string = "";
			for (String layout_col : layout_cols) {
				layout_col_string = layout_col_string + layout_col + ",";
			}
			String sqllayoutline = " INTO FILE_POSITIONAL_LAYOUT ("
					+ layout_col_string.substring(0, layout_col_string.length() - 1) 
					+ ") VALUES ('" + layoutName + "',";

			HashMap<Integer, ArrayList<Cell>> cellMap = layoutXLS.getRowCellMap("Metadata");
			String sqlLayoutValues = "";
			for (Integer row : cellMap.keySet()) {
				if (row > layoutRowStart) {
					sqlLayoutValues = "";
					ArrayList<Cell> cells = cellMap.get(row);
					int cellRowCount = 1;
					for (Cell cell : cells) {
						if (cellRowCount < layout_cols.length) {
							if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
								sqlLayoutValues = sqlLayoutValues + cell.getStringCellValue() + ",";
							} else {
								String cellString = cell.getStringCellValue();
								if (cellString.length() < 50) {
									sqlLayoutValues = sqlLayoutValues + "'" + cellString.replaceAll("'", "\"") + "',";
								} else {
									sqlLayoutValues = sqlLayoutValues + "'"
										+ cellString.substring(0, 49).replaceAll("'", "\"") + "',";
								}
							}
						}
						cellRowCount++;
					}
					sqllayout = sqllayout + sqllayoutline 
							+ sqlLayoutValues.substring(0, sqlLayoutValues.length() - 1)
							+ ")";
				}
			}
			sqllayout = sqllayout.concat(" SELECT * FROM dual ");
			System.out.println("\n" + sqllayout);
			SQLDataObject sqldatalayout = new SQLDataObject("oracle", "DTDMTX", sqllayout);
		} else {
			/*
			 * mede file xls
			 */
			sqldetail = sqldetail + "FILE_NAME,DELIMITER,BUSINESS_DOMAIN,PRIMARY_KEY) VALUES ('" 
			 + sheetName + "','|','NO DOMAIN','NO KEY')";
			System.out.println("\n" + sqldetail);
			SQLDataObject sqldatadetail = new SQLDataObject("oracle", "DTDMTX", sqldetail);
			/*
			 * layout insert
			 */
			String sqllayout = "INSERT ALL ";
			String sqllayoutline = " INTO FILE_POSITIONAL_LAYOUT "
					+ "(FILE_NAME,SCOLUMN_NAME,SCOLUMN_TYPE,SSIZE,RCOLUMN_NAME,RCOLUMN_TYPE,RSIZE"
					+ ") VALUES ('" + sheetName + "',";


			layoutRowStart=1000;
			for (Integer row : layoutMap.keySet()) {
				String[] layoutStrings = layoutMap.get(row).split(delim.toString());
				if(layoutStrings.length<1) break;
				if(layoutStrings[0].length()<1) break;
				if (layoutStrings[0].equals("#")) layoutRowStart = row;
				if (row > layoutRowStart) {
					String sqlLayoutValues = ""; 
					sqlLayoutValues = sqlLayoutValues.concat(sqllayoutline); 
					System.out.println(layoutMap.get(row));
					if(layoutStrings[2].contains(",")) {
						sqlLayoutValues = sqlLayoutValues.concat("'DERIVED',");
					} else {
						sqlLayoutValues = sqlLayoutValues.concat("'" + layoutStrings[2]+ "',");
					}
					sqlLayoutValues = sqlLayoutValues.concat("'" + layoutStrings[7]+ "',");
					sqlLayoutValues = sqlLayoutValues.concat("'" + layoutStrings[8]+ "',");
					sqlLayoutValues = sqlLayoutValues.concat("'" + layoutStrings[4]+ "',");
					sqlLayoutValues = sqlLayoutValues.concat("'" + layoutStrings[7]+ "',");
					sqlLayoutValues = sqlLayoutValues.concat("'" + layoutStrings[8]+ "')");
					sqllayout = sqllayout.concat(sqlLayoutValues);
				}
			}
			sqllayout = sqllayout.concat(" SELECT * FROM dual ");
			System.out.println("\n" + sqllayout);
			SQLDataObject sqldatalayout = new SQLDataObject("oracle", "DTDMTX", sqllayout);
		}

	}

	final class PositionalCell {
		String metaName = "";
		String dataType = "String";
		Integer colStart = 0;
		Integer dataSize = 0;
		Object value = null;
		String returnString = null;
	}

}
