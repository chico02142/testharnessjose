package com.gorski.apiproof;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

//import jcifs.smb.NtlmPasswordAuthentication;
//import jcifs.smb.SmbFile;

public class RemoteFileConnect {

	public RemoteFileConnect(String smbremoteFilePath, String fileName, String domain, String userName,
			String password) {
		// TODO Auto-generated constructor stub
	}
	public RemoteFileConnect() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) throws IOException {
		String domain="bcbsmamd";
	    String userName="_autotest01";
	    String password="Bcbsma2018!";
	    String fileName="MO_700_FX_20180530_110005_CDDM.csv";
	    String smbremoteFilePath=
	    		"smb://BOS0105FAP03/Public/DWUSERS/DLAP_Analyst/Ingested Files/Be2ME/RME/FeedFile/";
	    
	    /*
	     * try to mount
	     */
	    InputStream iStream = RemoteFileConnect.getInputStream(
	    		smbremoteFilePath, fileName, domain, userName, password);
	    RemoteFileConnect.printStream(iStream);

	}
	public static void printStream(InputStream fis) {
	    BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
        String line;
        try {
        	while ((line = reader.readLine()) != null) {
            	System.out.println(line);
        	}
        } catch(Exception e) {
           	e.printStackTrace();
        }
		
	}
	
	
	public static InputStream openFile(String fileName) {
		InputStream iStream = null;
		try {
			if(fileName.contains(":")||fileName.contains("./")) {
				iStream = new FileInputStream(fileName);
			} else {
		    /*
		     * try to mount
		     */
				Properties props = Tools.loadProp();
				String domain= props.getProperty("FSdomain");
				String userName= props.getProperty("FSuserName");
				String password= props.getProperty("FSpassword");
				//String smbremoteFilePath= "smb:"+props.getProperty("FSremoteFilePath");
		    
				iStream = RemoteFileConnect.getInputStream(
		    		"smb:", fileName, domain, userName, password);
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return iStream;
	}
	
	public static InputStream getInputStream(
			String URL, String fileName, String domain, String userName, String password) {
		InputStream fis = null;
//	    NtlmPasswordAuthentication mauth = new NtlmPasswordAuthentication(
//	    		domain,userName,password);
//	    SmbFile fileToRead;
//		try {
//			fileToRead = new SmbFile(URL+fileName,mauth);
//			fis = fileToRead.getInputStream();
//		} 
//		catch (IOException e) {
			System.out.println(" FILE FAIL "+URL+fileName);
//			e.printStackTrace();
//		}
		return fis;
	}

}
